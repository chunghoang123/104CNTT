import React from "react";

export function ListCourse() {
  return (
    <>
      <h1>Danh sách khoá học</h1>
      <ol>
        <li>HTML</li>
        <li>CSS</li>
        <li>JavaScript</li>
        <li>ReactJs</li>
      </ol>
    </>
  );
}
