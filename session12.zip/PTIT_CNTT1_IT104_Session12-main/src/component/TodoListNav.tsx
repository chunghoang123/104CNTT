import React from "react";

export const TodoListNav = () => {
  return (
    <ul className="nav nav-tabs mb-4 pb-2" id="ex1" role="tablist">
      <li className="nav-item" role="presentation">
        <a className="nav-link active">Tất cả công việc</a>
      </li>
    </ul>
  );
};
